import { StyleSheet, Text, View, FlatList } from "react-native";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { User } from "../types/user";
import ProductCard from "../components/UserCard";

const Home = () => {
  const [userList, setUserList] = useState<User[]>([]);
  const URL = "https://melivecode.com/api/users";

  const getUser = async () => {
    try {
      const response = await axios.get<User[]>(
        `${URL}`
      );
      setUserList(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getUser();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Users</Text>
      <FlatList
        data={userList}
        renderItem={({ item }) => <ProductCard user={item} />}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#343a40",
    color: "#FFFFFF",
    padding: 10,
  },
  text: {
    color: "#FFFFFF",
    fontSize: 28,
  },
});