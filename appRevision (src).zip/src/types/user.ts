export interface User {
  id: number;
  fname: string;
  lname: string;
  username: string;
  avatar: string
}